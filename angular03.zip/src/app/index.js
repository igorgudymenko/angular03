'use strict';

angular.module('angular03', ['ui.router'])
  .config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('login', {
        url: '/login',
        templateUrl: 'app/login/login.html',
        controller: 'LoginCtrl'
      })
      .state('page1', {
        url: '/page1:user',
        templateUrl: 'app/page1/page1.html',
        controller: 'Page1Ctrl'
      })
      .state('page2', {
        url: '/page2:user',
        templateUrl: 'app/page2/page2.html',
        controller: 'Page2Ctrl'
      })
      .state('admin', {
        url: '/admin:user',
        templateUrl: 'app/admin/admin.html',
        controller: 'AdminCtrl'
      })
    ;

    $urlRouterProvider.otherwise('/login');
  })
;
