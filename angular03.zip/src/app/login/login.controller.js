'use strict';

angular.module('angular03')
  .controller('LoginCtrl', function ($scope, $state) {
    window.localStorage.setItem('username', null);
    $scope.login = function() {
      window.localStorage['username'] = $scope.user;
      $state.go('page1')
    };
  });
